MOVE//MODE — Chrome extension (version 1.1.0)

Installation:
1. Extract this ZIP to a permanent folder.
2. Open chrome://extensions in Chrome.
3. Enable Developer mode, then click Load unpacked.
4. Choose the move_mode_extension folder.
5. Click the extension icon to open the dashboard. Pin that tab if you like.

The five themes (AI, Meetings, Browser, Work, Bed) rotate on the dashboard.
Click a theme to keep it selected for about 90 seconds. Notifications rotate
through enabled themes across each day and include matching context and
a short exercise. The dashboard tracks optional check-offs and local analytics.

Three reminder alarms are randomized between configured hours each day.
Chrome must be running (or background execution permitted), and system
notification settings and Do Not Disturb may affect visibility.
The extension cannot actually detect whether Claude is busy, Zoom camera
is off, or a tab has frozen. Messages are playful scenarios, not live status.

Your completion history remains in chrome.storage.local on an extension
update with the same extension ID (reload the same unpacked directory).
Using a new installation location can generate a new extension ID and
separate storage. Back up your history via Export JSON before moving it.

For exercise safety, use gentle, symptom-limited movement and avoid
continuing through pain or prominent abdominal doming.
