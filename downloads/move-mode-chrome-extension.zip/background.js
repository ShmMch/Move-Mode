importScripts('modes.js');
const DEFAULT_SETTINGS = {start:'09:00',end:'21:00',lang:'he',enabled:true};
const SCHEDULE_PREFIX='move-';
const DAILY_ALARM='move-daily-refresh';
const pad=n=>String(n).padStart(2,'0');
const dateKey=d=>`${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`;
const minute=t=>{const [h,m]=t.split(':').map(Number);return h*60+m};
const today=()=>dateKey(new Date());
async function data(){const stored=await chrome.storage.local.get(['settings','schedule','fired','history']);return {settings:{...DEFAULT_SETTINGS,...stored.settings},schedule:stored.schedule||{},fired:stored.fired||{},history:stored.history||{}}}
function randomSlots(start,end){const a=minute(start),b=minute(end),range=b-a;if(!(range>=90))return randomSlots('09:00','21:00');return [0,1,2].map(i=>{const lo=a+Math.floor(range*i/3),hi=a+Math.floor(range*(i+1)/3)-1;return lo+Math.floor(Math.random()*(hi-lo+1))}).sort((x,y)=>x-y)}
function scheduledAt(key,m){const [y,mo,day]=key.split('-').map(Number);return new Date(y,mo-1,day,Math.floor(m/60),m%60,0,0).getTime()}
async function clearMoveAlarms(){const alarms=await chrome.alarms.getAll();await Promise.all(alarms.filter(a=>a.name.startsWith(SCHEDULE_PREFIX)).map(a=>chrome.alarms.clear(a.name)))}
async function plan(force=false){const s=await data(),key=today(),now=Date.now();await clearMoveAlarms();
 if(!s.settings.enabled){await chrome.alarms.create(DAILY_ALARM,{when:nextMidnight()});return}
 let slots=s.schedule[key];if(force||!Array.isArray(slots)||slots.length!==3){slots=randomSlots(s.settings.start,s.settings.end);s.schedule[key]=slots;if(force)s.fired[key]=[]}
 const keepKeys=[key,dateKey(new Date(now-86400000))];s.schedule=Object.fromEntries(Object.entries(s.schedule).filter(([k])=>keepKeys.includes(k)));s.fired=Object.fromEntries(Object.entries(s.fired).filter(([k])=>keepKeys.includes(k)));
 await chrome.storage.local.set({schedule:s.schedule,fired:s.fired});
 for(let i=0;i<slots.length;i++){const id=`${SCHEDULE_PREFIX}${key}-${i}`;if(scheduledAt(key,slots[i])>now+1000&&!s.fired[key]?.includes(i))await chrome.alarms.create(id,{when:scheduledAt(key,slots[i])})}
 await chrome.alarms.create(DAILY_ALARM,{when:nextMidnight()});
}
function nextMidnight(){const d=new Date();return new Date(d.getFullYear(),d.getMonth(),d.getDate()+1,0,1).getTime()}
const ALL_CATEGORIES = MOVE_MODES.map(m=>m.id);
function enabledModes(settings){const requested=settings.categories;const allowed=Array.isArray(requested)?requested.filter(x=>ALL_CATEGORIES.includes(x)):ALL_CATEGORIES;return allowed.length?allowed:ALL_CATEGORIES}
async function notificationChoice(settings,key,index){
 const options=enabledModes(settings);
 // Cycle through all five categories before repeating, with a different daily order.
 const seed=[...key].reduce((a,c)=>((a*31+c.charCodeAt(0))>>>0),17);
 const order=[...options];let x=seed;
 for(let j=order.length-1;j>0;j--){x=(Math.imul(x,1664525)+1013904223)>>>0;const k=x%(j+1);[order[j],order[k]]=[order[k],order[j]]}
 const mode=MOVE_BY_ID[order[index%order.length]];
 const item=mode.messages[Math.floor(Math.random()*mode.messages.length)];
 return {mode:mode.id,title:item[settings.lang==='en'?2:0],message:item[settings.lang==='en'?3:1],move:item[4]};
}
async function notify(index,key){const s=await data();if(!s.settings.enabled)return;if(s.fired[key]?.includes(index))return;
 const choice=await notificationChoice(s.settings,key,index);
 const fired={...s.fired,[key]:[...(s.fired[key]||[]),index]};
 const lastReminder={...choice,key,index,at:Date.now()};
 await chrome.storage.local.set({fired,lastReminder});
 await chrome.notifications.create(`move-${key}-${index}`,{type:'basic',iconUrl:`icons/${choice.mode}128.png`,title:choice.title,message:choice.message,priority:2,requireInteraction:false});
}
chrome.alarms.onAlarm.addListener(async alarm=>{if(alarm.name===DAILY_ALARM){await plan();return}const m=/^move-(\d{4}-\d{2}-\d{2})-(\d)$/.exec(alarm.name);if(m){if(m[1]!==today())return;await notify(Number(m[2]),m[1])}});
chrome.runtime.onInstalled.addListener(async()=>{await plan();});
chrome.runtime.onStartup.addListener(async()=>{await plan();});
chrome.action.onClicked.addListener(async()=>{const url=chrome.runtime.getURL('dashboard.html');const tabs=await chrome.tabs.query({url});if(tabs.length){await chrome.tabs.update(tabs[0].id,{active:true});await chrome.windows.update(tabs[0].windowId,{focused:true})}else await chrome.tabs.create({url})});
chrome.notifications.onClicked.addListener(async id=>{await chrome.notifications.clear(id);const url=chrome.runtime.getURL('dashboard.html');const tabs=await chrome.tabs.query({url});if(tabs.length){await chrome.tabs.update(tabs[0].id,{active:true});await chrome.windows.update(tabs[0].windowId,{focused:true})}else await chrome.tabs.create({url})});
chrome.runtime.onMessage.addListener((msg,sender,send)=>{if(msg.type==='reschedule'){plan(!!msg.force).then(()=>send({ok:true})).catch(e=>send({ok:false,error:String(e)}));return true}if(msg.type==='test-notification'){(async()=>{const s=await data();const key=today(),index=Math.floor(Math.random()*5);const choice=await notificationChoice(s.settings,key,index);await chrome.storage.local.set({lastReminder:{...choice,key,index,at:Date.now()}});await chrome.notifications.create('move-test-'+Date.now(),{type:'basic',iconUrl:`icons/${choice.mode}128.png`,title:choice.title,message:choice.message,priority:2});send({ok:true})})().catch(e=>send({ok:false,error:String(e)}));return true}});

